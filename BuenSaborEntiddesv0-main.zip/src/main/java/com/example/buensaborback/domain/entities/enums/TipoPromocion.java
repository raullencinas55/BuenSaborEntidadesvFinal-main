package com.example.buensaborback.domain.entities.enums;

public enum TipoPromocion {
    HappyHour,
    Promocion
}
