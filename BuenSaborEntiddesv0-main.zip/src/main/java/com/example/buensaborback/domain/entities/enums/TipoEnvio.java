package com.example.buensaborback.domain.entities.enums;

public enum TipoEnvio {
    Delivery,
    TakeAway
}
