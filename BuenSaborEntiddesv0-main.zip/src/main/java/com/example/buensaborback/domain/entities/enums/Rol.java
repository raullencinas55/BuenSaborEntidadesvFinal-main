package com.example.buensaborback.domain.entities.enums;

public enum Rol {
    Admin,
    Empleado,
    Cliente
}
