package com.example.buensaborback.domain.entities.enums;

public enum FormaPago {
    Efectivo,
    MercadoPago
}
