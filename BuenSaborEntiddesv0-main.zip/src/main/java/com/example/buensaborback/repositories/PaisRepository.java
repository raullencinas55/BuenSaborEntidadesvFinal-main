package com.example.buensaborback.repositories;

import com.example.buensaborback.domain.entities.Pais;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaisRepository extends JpaRepository<Pais,Long> {
}
