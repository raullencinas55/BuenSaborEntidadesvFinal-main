package com.example.buensaborback.repositories;

import com.example.buensaborback.domain.entities.Imagen;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ImagenRepository extends JpaRepository<Imagen,Long> {
}
