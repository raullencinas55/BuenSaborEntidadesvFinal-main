package com.example.buensaborback.repositories;

import com.example.buensaborback.domain.entities.Provincia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProvinciaRepository extends JpaRepository<Provincia,Long> {
}
